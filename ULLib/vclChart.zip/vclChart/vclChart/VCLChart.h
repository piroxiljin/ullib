///\file VCLChart.h
///\brief ������������ ���� ������ ������ ��� vcl - �����
#pragma once
///\class CVCLChart
///\brief ����� VCL �����, ������� �������� � ���(���� �����������)(2006)
class CVCLChart
{
	HMODULE m_hLib;
public:
	HWND m_hVCLChart;
//==================================================
	enum enLineType
	{
		psSolid=1,
		psClear=2,
		psDash=3,
		psDashDot=4,
		psDashDotDot=5,
		psDot=6,
		psInsideFrame=7
	};
//==================================================
	CVCLChart(void)
	{
		m_hLib=LoadLibrary("vclChart/vclChart.dll");
		if(m_hLib==NULL) 
		{
			::MessageBox(0,"Not load library vclChart.dll","Error",0);
			return;
		}

	}
	~CVCLChart(void)
	{
		FreeLibrary(m_hLib);
	}

	BOOL Create(HWND hParentWnd, int x, int y, int cx, int cy)
	{
		typedef HWND(_cdecl* VCL_CREATE_CHART_WND)(HWND hParentWnd);
		VCL_CREATE_CHART_WND vclCreateChartWnd=(VCL_CREATE_CHART_WND)GetProcAddress(m_hLib,"CreateChartWnd");
		if(vclCreateChartWnd==NULL)
		{
			::MessageBox(0,"Not load vclCreateChartWnd","Error",0);
			return FALSE;
		}
		m_hVCLChart=vclCreateChartWnd(hParentWnd);
		SetWindowPos(m_hVCLChart,HWND_TOP,x,y,cx,cy,SWP_SHOWWINDOW);
		return TRUE;
	}

	BOOL AddSeries(double* pBufX,double* pBufY, int iBufLen, UINT uiColor, TCHAR* szName,int iWidth,enLineType lType)
	{
		typedef BOOL(_cdecl* VCL_ADD_SERIES)(double** pBuffer, int iBufLen, UINT uiColor, TCHAR* szName,int iWidth,int iType);
		VCL_ADD_SERIES vclAddSeries=(VCL_ADD_SERIES)GetProcAddress(m_hLib,"AddSeries");
		if(vclAddSeries==NULL)
		{
			::MessageBox(0,"Not load AddSeries","Error",0);
			return FALSE;
		}
		double **pBuffer;
		pBuffer=new double*[2];
		pBuffer[0]=pBufX;
		pBuffer[1]=pBufY;
		vclAddSeries(pBuffer,iBufLen,uiColor,szName,iWidth,lType);
		return TRUE;
	}
	BOOL SeriesLegend(BOOL bVisible)
	{
		typedef BOOL(_cdecl* VCL_SERIES_LEGEND)(BOOL bVisible);
		VCL_SERIES_LEGEND vclSeriesLegend=(VCL_SERIES_LEGEND)GetProcAddress(m_hLib,"SeriesLegend");
		if(vclSeriesLegend==NULL)
		{
			::MessageBox(0,"Not load SeriesLegend","Error",0);
			return FALSE;
		}
		vclSeriesLegend(bVisible);
		return TRUE;
	}
	BOOL ClearSeries(void)
	{
		typedef BOOL(_cdecl* VCL_CLEAR_SERIES)();
		VCL_CLEAR_SERIES vclClearSeries=(VCL_CLEAR_SERIES)GetProcAddress(m_hLib,"ClearSeries");
		if(vclClearSeries==NULL)
		{
			::MessageBox(0,"Not load ClearSeries","Error",0);
			return FALSE;
		}
		vclClearSeries();
		return TRUE;
	}
};
